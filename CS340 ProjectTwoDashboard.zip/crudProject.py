import pymongo
import traceback
import json
from pymongo import MongoClient
from pymongo.errors import WriteConcernError, WriteError
from bson.objectid import ObjectId



class AnimalShelter(object):
    
    """CRUD Operations for Animal collection in MongoDB"""
    
    def __init__(self, username: str, password: str):
        #initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:54915/?authMechanism=DEFAULT&authSource=AAC' % (username, password))
        self.database = self.client['AAC']["animals"]
        
# Complete this create method to implement the C in CRUD
    def create(self, data:dict) -> bool:
        if data is not None:
            self.database.insert_one(data) # data should be dictionary
            inserted = True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        
        return inserted
        
# Method to implement the R in CRUD
    def read(self, data:dict):
        if data is not None:
            results = self.database.find(data)
            return results
        else:
            raise Exception("Something went wrong. Check the criteria and try again")
        
# Method to implement the U in CRUD
    def update(self, data:dict, newValues: dict):
        result = None
        try:
            if data is not None and newValues is not None:
                result = self.database.update_one(data, {"$set": newValues})
                if result.modified_count != 0:
                    print("Successfully updated")
                else:
                    print("Failed to update")
                    
                    # return json object
                json_object = json.dumps(result.raw_result, indent = 4)
                return json_object
            else:
                raise Exception("look up values or update values were not specified")
        except WriteConcernError as wce:
            print("A WriteConcernError occurred")
            return wce
        except WriteError as we:
            print("A WriteError occurred")
            return we
        except:
            print("An error occurred when trying to update the document")
            traceback.print_exc()         


# Method to implement the D in CRUD
    def delete(self, data: dict):
        try:
            if data is not None:
                result = self.database.delete_one(data)
                if result.deleted_count > 0:
                    print("Successful deletion")
                    
                else:
                    print("Failed deletion")
                json_object = json.dumps(result.raw_result, indent = 4)
                return json_object
            else:
                raise Exception("Delete was null")
                
        except WriteConcernError as wce:
            print("A WriteConcernError occurred")
            return wce
        except WriteError as we:
            print("A WriteError occurred")
            return we
        except:
            print("An error occurred")
            traceback.print_exc()

